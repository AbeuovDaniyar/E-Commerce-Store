var searchData=
[
  ['_24_0',['$',['../_cart_2_index_8cshtml_8g_8cs.html#a58859d93c30e635814dc980ed86e3f84',1,'$():&#160;Index.cshtml.g.cs'],['../_details_8cshtml_8g_8cs.html#a58859d93c30e635814dc980ed86e3f84',1,'$():&#160;Details.cshtml.g.cs'],['../_product_details_8cshtml_8g_8cs.html#a58859d93c30e635814dc980ed86e3f84',1,'$():&#160;ProductDetails.cshtml.g.cs']]]
];
