var searchData=
[
  ['requestid_0',['RequestId',['../class_capstone_project_1_1_models_1_1_error_view_model.html#a5a60589ad087efc13b4899c0094c59a5',1,'CapstoneProject::Models::ErrorViewModel']]],
  ['role_1',['Role',['../class_capstone_project_1_1_models_1_1_user.html#a5b73a6b4b99b0ff254c13dd22069381e',1,'CapstoneProject::Models::User']]]
];
