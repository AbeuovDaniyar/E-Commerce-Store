var searchData=
[
  ['the_20mit_20license_20_28mit_29_0',['The MIT License (MIT)',['../md_wwwroot_lib_jquery_validation__l_i_c_e_n_s_e.html',1,'']]]
];
