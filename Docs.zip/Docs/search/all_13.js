var searchData=
[
  ['quantity_0',['Quantity',['../class_capstone_project_1_1_models_1_1_item.html#a1b5e9274198dd017d2a42c0b9474df82',1,'CapstoneProject::Models::Item']]],
  ['quantity_1',['quantity',['../class_capstone_project_1_1_models_1_1_order_item.html#ac7cdc4a702a0a20fa8b05695d05ee988',1,'CapstoneProject::Models::OrderItem']]]
];
