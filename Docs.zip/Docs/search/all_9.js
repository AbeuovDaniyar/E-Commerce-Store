var searchData=
[
  ['firstname_0',['FirstName',['../class_capstone_project_1_1_models_1_1_user.html#a2fb6cf028782b0854957cf5332f966a5',1,'CapstoneProject::Models::User']]]
];
