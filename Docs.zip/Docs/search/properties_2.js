var searchData=
[
  ['email_0',['Email',['../class_capstone_project_1_1_models_1_1_user.html#a0093b06e320941ba6fdde3a49e06dd0a',1,'CapstoneProject::Models::User']]]
];
