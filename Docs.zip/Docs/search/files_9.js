var searchData=
[
  ['license_2emd_0',['LICENSE.md',['../_l_i_c_e_n_s_e_8md.html',1,'']]],
  ['login_2ecshtml_2eg_2ecs_1',['Login.cshtml.g.cs',['../_login_8cshtml_8g_8cs.html',1,'']]]
];
