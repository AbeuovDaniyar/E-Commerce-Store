var searchData=
[
  ['startup_0',['Startup',['../class_capstone_project_1_1_startup.html',1,'CapstoneProject']]],
  ['supplements_1',['Supplements',['../class_capstone_project_1_1_models_1_1_supplements.html',1,'CapstoneProject::Models']]]
];
