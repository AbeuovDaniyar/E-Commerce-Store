var searchData=
[
  ['login_0',['Login',['../class_capstone_project_1_1_controllers_1_1_home_controller.html#af985621d43eb4e8c98afb52124d5c073',1,'CapstoneProject::Controllers::HomeController']]],
  ['logout_1',['Logout',['../class_capstone_project_1_1_controllers_1_1_home_controller.html#ae72a9c00bbbbd6857e5c986ee001e6ed',1,'CapstoneProject::Controllers::HomeController']]]
];
