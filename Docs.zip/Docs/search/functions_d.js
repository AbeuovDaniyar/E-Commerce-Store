var searchData=
[
  ['register_0',['Register',['../class_capstone_project_1_1_controllers_1_1_home_controller.html#aea152405c1290bc94c8317651a85e2cd',1,'CapstoneProject::Controllers::HomeController']]],
  ['removeproduct_1',['RemoveProduct',['../class_capstone_project_1_1_controllers_1_1_cart_controller.html#af7e88049c8b72b762d6c2669174d4a86',1,'CapstoneProject::Controllers::CartController']]]
];
